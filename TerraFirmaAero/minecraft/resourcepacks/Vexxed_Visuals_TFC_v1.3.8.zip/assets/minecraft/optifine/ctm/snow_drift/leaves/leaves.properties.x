matchBlocks=tfc:wood/leaves/acacia tfc:wood/leaves/ash tfc:wood/leaves/aspen tfc:wood/leaves/birch tfc:wood/leaves/blackwood tfc:wood/leaves/chestnut tfc:wood/leaves/douglas_fir tfc:wood/leaves/hickory tfc:wood/leaves/kapok tfc:wood/leaves/mangrove tfc:wood/leaves/maple tfc:wood/leaves/oak tfc:wood/leaves/palm tfc:wood/leaves/pine tfc:wood/leaves/rosewood tfc:wood/leaves/sequoia tfc:wood/leaves/spruce tfc:wood/leaves/sycamore tfc:wood/leaves/white_cedar tfc:wood/leaves/willow
method=overlay
tiles=0-16
connect=block
connectBlocks=snow snow_block
faces=sides